// Ada Pici, apici2
// apici2@uic.edu
// Project 1
// This project implements my own version of the stack and queue data structures

public class GLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to project 1");

	}
}
